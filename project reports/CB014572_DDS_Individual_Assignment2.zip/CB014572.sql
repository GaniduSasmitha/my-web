--Table Creation--

CREATE DATABASE Nestle_DB;
GO

USE Nestle_DB;
GO


-- Supplier Table
CREATE TABLE Supplier (
    SupplierID INT  NOT NULL PRIMARY KEY IDENTITY(1,1),
    SupplierName VARCHAR(100) NOT NULL,
    ContactEmail VARCHAR(100) NOT NULL,
    Phone VARCHAR(15) NOT NULL,
    Address VARCHAR(255) NOT NULL
);
PRINT 'Table Supplier created successfully';
GO

-- Employee Table
CREATE TABLE Employee (
    EmployeeID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    EmployeeName VARCHAR(100) NOT NULL,
    [Role] VARCHAR(50) NOT NULL,
    Department VARCHAR(100) NOT NULL
);
PRINT 'Table Employee created successfully';
GO

--Warehouse Table
CREATE TABLE Warehouse (
    WarehouseID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    WarehouseName VARCHAR(100) NOT NULL,
    LocationName VARCHAR(100) NOT NULL,
    Capacity INT NOT NULL
);
PRINT 'Table Warehouse created successfully';
GO

--Appliance Table
CREATE TABLE Appliance (
    SerialNO VARCHAR(20) NOT NULL PRIMARY KEY,
    SupplierID INT NOT NULL,
    Brand VARCHAR(100) NOT NULL,
    [Description] VARCHAR(255) NULL,
    Cost DECIMAL(10,2) NOT NULL,
    CONSTRAINT FK_Appliance_Supplier FOREIGN KEY (SupplierID) REFERENCES Supplier(SupplierID)
);
PRINT 'Table Appliance created successfully';
GO

--Purchase Order Table
CREATE TABLE PurchaseOrder (
    PurchaseOrderID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    SupplierID INT NOT NULL,
    EmployeeID INT NOT NULL,
    OrderDate DATE NOT NULL DEFAULT GETDATE(),
    TotalAmount DECIMAL(18,2),
    CONSTRAINT FK_PO_Supplier FOREIGN KEY (SupplierID) REFERENCES Supplier(SupplierID),
    CONSTRAINT FK_PO_Employee FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID)
);
PRINT 'Table PurchaseOrder created successfully';
GO

--OrderDetails Table
CREATE TABLE PurchaseOrderDetails (
    PurchaseOrderID INT NOT NULL,
    SerialNO VARCHAR(20) NOT NULL,
    Quantity INT NOT NULL CHECK (Quantity > 0),
    UnitPrice DECIMAL(10,2) NOT NULL CHECK (UnitPrice > 0),
    PRIMARY KEY (PurchaseOrderID, SerialNO),
    CONSTRAINT FK_Details_PO FOREIGN KEY (PurchaseOrderID) REFERENCES PurchaseOrder(PurchaseOrderID),
    CONSTRAINT FK_Details_Appliance FOREIGN KEY (SerialNO) REFERENCES Appliance(SerialNO)
);
PRINT 'Table PurchaseOrderDetails created successfully';
GO

--Payment Table
CREATE TABLE Payment (
    PaymentID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    PurchaseOrderID INT NOT NULL,
    PaymentDate DATE NOT NULL DEFAULT GETDATE(),
    [Status] VARCHAR(50) NOT NULL CHECK ([Status] IN ('Paid', 'Pending', 'Failed', 'Refunded')),
    CONSTRAINT FK_Payment_PO FOREIGN KEY (PurchaseOrderID) REFERENCES PurchaseOrder(PurchaseOrderID)
);
PRINT 'Table Payment created successfully';
GO



--Data Insertion--

USE Nestle_DB;
GO


-- 1.Suppliers (Local Engineering & Logistics)
INSERT INTO Supplier (SupplierName, ContactEmail, Phone, Address)
VALUES 
('Lanka Industrial Solutions', 'sales@lankaindustrial.lk', '0115551234', 'No 15, Industrial Estate, Ekala'),
('Kurunegala Tech Services', 'support@kuru-tech.lk', '0372229876', 'No 88, Puttalam Road, Kurunegala'),
('Colombo Cold Storage Ltd', 'info@ccs.lk', '0114445555', 'No 22, Ranmuthugala, Kadawatha'),
('Ceylon Engineering Co.', 'contact@ceyloneng.com', '0112334455', 'No 10, Kandy Road, Kelaniya'),
('PureWater Systems SL', 'tech@purewater.lk', '0117778888', 'No 5, Galle Road, Colombo 03'),
('Island Logistics Partners', 'ops@islandlog.lk', '0119990000', 'No 100, Negombo Road, Peliyagoda'),
('Precision Lab Equipment', 'labs@precision.lk', '0116667777', 'No 45, Highlevel Road, Nugegoda'),
('Smart Power SL', 'energy@smartpower.lk', '0112112233', 'No 12, Nawala Road, Rajagiriya'),
('Packaging World Lanka', 'sales@packworld.lk', '0118889999', 'No 7, Minuwangoda Road, Ja-Ela'),
('Eco-Solutions Sri Lanka', 'green@ecosolutions.lk', '0375556666', 'No 30, Lake Round, Kurunegala');
PRINT '10 Suppliers added successfully.';

-- 2. Employees (Nestl� Supply Chain & Factory Staff)
INSERT INTO Employee (EmployeeName, [Role], Department)
VALUES 
('Nilmini Silva', 'Inventory Controller', 'Warehouse'),
('Kasun Jayasinghe', 'Maintenance Engineer', 'Technical'),
('Dilani Perera', 'Procurement Officer', 'Supply Chain'),
('Rohan Abeyratne', 'Quality Assurance lead', 'Production'),
('Anura Bandara', 'Warehouse Supervisor', 'Logistics'),
('Samanthi Fernando', 'Financial Analyst', 'Finance'),
('Mahesh Kumara', 'Production Planner', 'Operations'),
('Ishara De Silva', 'Safety Officer', 'HR & Safety'),
('Thilini Wijesinghe', 'Compliance Manager', 'Legal'),
('Aruna Rathnayake', 'Fleet Manager', 'Transport');
PRINT '10 Employees added successfully.';

-- 3.Warehouses (Nestl� Storage Facilities)
INSERT INTO Warehouse (WarehouseName, LocationName, Capacity)
VALUES 
('Kurunegala Factory A', 'Bauddhaloka Mawatha, Kurunegala', 10000),
('Pannala Distribution Center', 'Main Road, Pannala', 15000),
('Colombo Head Office Store', 'No 440, Pannipitiya Road, Pelawatta', 2000),
('Kandy Regional Hub', 'Peradeniya Road, Kandy', 5000),
('Galle Cold Storage', 'Matara Road, Galle', 4000),
('Jaffna Logistics Point', 'KKS Road, Jaffna', 3000),
('Ekala Raw Material Yard', 'Industrial Zone, Ekala', 8000),
('Trincomalee Depot', 'Harbour Road, Trincomalee', 3500),
('Ratnapura Transit Point', 'Colombo Road, Ratnapura', 2500),
('Anuradhapura Center', 'Maithripala Senanayake Mawatha', 4500);
PRINT '10 Warehouses added successfully.';

-- 4.Appliances (Nestl� Professional & Factory Equipment)
INSERT INTO Appliance (SerialNO, SupplierID, Brand, [Description], Cost)
VALUES 
('NP-VEN-001', 1, 'Nestl� Professional', 'Multi-Option Hot Beverage Vending Machine', 450000.00),
('NP-VEN-002', 1, 'Nestl� Professional', 'Alegria Coffee Solution Machine', 380000.00),
('NP-COLD-01', 2, 'Nestl� CoolPro', 'Proprietary Smart Cool Beverage Dispenser', 520000.00),
('NP-PREM-05', 1, 'Nestl� Premio', 'Premium Bean-to-Cup Coffee Machine', 850000.00),
('FAC-MIX-10', 2, 'Industrial Tech', 'Large Scale Milk Powder Industrial Mixer', 2500000.00),
('FAC-PACK-02', 4, 'PackLine', 'Milo Sachet High-Speed Packaging Machine', 4200000.00),
('FAC-CHIL-08', 3, 'CoolLanka', 'Bulk Milk Cooling Tank (5000 Liters)', 1200000.00),
('NP-FRIO-03', 1, 'Nestl� FRIO', 'Cold Milo & Iced Coffee Dispenser', 480000.00),
('FAC-BOIL-01', 8, 'SteamMasters', 'Industrial Steam Boiler for Maggi Production', 3100000.00),
('FAC-LAB-99', 7, 'LabTech SL', 'Milk Quality Testing Spectrometer', 950000.00);
PRINT '10 Appliances added successfully.';

-- 5.Purchase Orders (Nestl� Procurement Headers)
INSERT INTO PurchaseOrder (SupplierID, EmployeeID, OrderDate, TotalAmount)
VALUES 
(1, 3, '2026-01-10', 1750000.00), 
(2, 2, '2026-01-12', 2500000.00), 
(4, 3, '2026-01-15', 4200000.00), 
(3, 5, '2026-01-18', 1200000.00), 
(8, 2, '2026-01-20', 3100000.00), 
(1, 3, '2026-01-22', 850000.00), 
(7, 4, '2026-01-25', 950000.00),  
(2, 3, '2026-01-28', 520000.00),  
(1, 1, '2026-02-01', 480000.00),  
(1, 3, '2026-02-03', 380000.00);  
PRINT '10 Purchase Orders added successfully.';

-- 6.Purchase Order Details (Linking Orders to Nestl� Equipment)
INSERT INTO PurchaseOrderDetails (PurchaseOrderID, SerialNO, Quantity, UnitPrice)
VALUES 
(1, 'NP-VEN-001', 2, 450000.00),
(1, 'NP-VEN-002', 2, 425000.00),
(2, 'FAC-MIX-10', 1, 2500000.00),
(3, 'FAC-PACK-02', 1, 4200000.00),
(4, 'FAC-CHIL-08', 1, 1200000.00),
(5, 'FAC-BOIL-01', 1, 3100000.00),
(6, 'NP-PREM-05', 1, 850000.00),
(7, 'FAC-LAB-99', 1, 950000.00),
(8, 'NP-COLD-01', 1, 520000.00),
(9, 'NP-FRIO-03', 1, 480000.00);
PRINT '10 Purchase Order Details added successfully.';

-- 7.Payments (Settling Nestl� Procurement Transactions)
INSERT INTO Payment (PurchaseOrderID, PaymentDate, [Status])
VALUES 
(1, '2026-01-15', 'Paid'),
(2, '2026-01-20', 'Paid'),
(3, '2026-01-25', 'Pending'),
(4, '2026-01-30', 'Paid'),
(5, '2026-02-05', 'Paid'),
(6, '2026-02-10', 'Failed'),
(7, '2026-02-12', 'Paid'),
(8, '2026-02-15', 'Refunded'),
(9, '2026-02-18', 'Paid'),
(10, '2026-02-20', 'Pending');
PRINT '10 Payments added successfully.';

GO


-- Query Reports--

USE Nestle_DB;
GO

-- 1. Display all Appliances with their Supplier and Cost
SELECT 
    a.SerialNO, 
    a.Description, 
    a.Brand, 
    s.SupplierName, 
    a.Cost
FROM Appliance a
JOIN Supplier s ON a.SupplierID = s.SupplierID
ORDER BY a.Cost DESC;


-- 2. Display all Purchase Orders and the Staff who created them
SELECT 
    po.PurchaseOrderID, 
    po.OrderDate, 
    e.EmployeeName, 
    e.Role, 
    s.SupplierName, 
    po.TotalAmount
FROM PurchaseOrder po
JOIN Employee e ON po.EmployeeID = e.EmployeeID
JOIN Supplier s ON po.SupplierID = s.SupplierID;


--3. Total Expenditure per Supplier
SELECT 
    s.SupplierName, 
    SUM(po.TotalAmount) AS TotalSpent
FROM Supplier s
JOIN PurchaseOrder po ON s.SupplierID = po.SupplierID
GROUP BY s.SupplierName
ORDER BY TotalSpent DESC;


--4. Count of Appliances provided by each Supplier
SELECT 
    s.SupplierName, 
    COUNT(a.SerialNO) AS NumberOfAppliances
FROM Supplier s
LEFT JOIN Appliance a ON s.SupplierID = a.SupplierID
GROUP BY s.SupplierName;


--5. Lists Outstanding (Pending) Payments for Orders
SELECT 
    p.PurchaseOrderID, 
    s.SupplierName, 
    p.Status, 
    po.TotalAmount, 
    p.PaymentDate
FROM Payment p
JOIN PurchaseOrder po ON p.PurchaseOrderID = po.PurchaseOrderID
JOIN Supplier s ON po.SupplierID = s.SupplierID
WHERE p.Status = 'Pending';


--6. Display the Most Frequently Ordered Brands
SELECT 
    a.Brand, 
    COUNT(pod.SerialNO) AS TimesOrdered, 
    SUM(pod.Quantity) AS TotalQuantityOrdered
FROM Appliance a
JOIN PurchaseOrderDetails pod ON a.SerialNO = pod.SerialNO
GROUP BY a.Brand
ORDER BY TotalQuantityOrdered DESC;


--7. Find Employees who managed orders exceeding 1,000,000 LKR
SELECT 
    e.EmployeeName, 
    e.Department, 
    COUNT(po.PurchaseOrderID) AS HighValueOrderCount
FROM Employee e
JOIN PurchaseOrder po ON e.EmployeeID = po.EmployeeID
WHERE po.TotalAmount > 1000000
GROUP BY e.EmployeeName, e.Department;


--8. Monthly Procurement Summary (Year 2026)
SELECT 
    MONTH(OrderDate) AS OrderMonth, 
    COUNT(PurchaseOrderID) AS TotalOrders, 
    SUM(TotalAmount) AS MonthlyExpenditure
FROM PurchaseOrder
WHERE YEAR(OrderDate) = 2026
GROUP BY MONTH(OrderDate);


--9. Detailed Breakdown of a Specific Purchase Order
SELECT 
    pod.PurchaseOrderID, 
    a.Description, 
    pod.Quantity, 
    pod.UnitPrice, 
    (pod.Quantity * pod.UnitPrice) AS Subtotal
FROM PurchaseOrderDetails pod
JOIN Appliance a ON pod.SerialNO = a.SerialNO
WHERE pod.PurchaseOrderID = 1; 


--10. List Suppliers based in specific Regions (e.g., Colombo)
SELECT 
    SupplierName, 
    ContactEmail, 
    Phone, 
    Address
FROM Supplier
WHERE Address LIKE '%Colombo%'; 


--Transaction-- 

BEGIN TRANSACTION;
BEGIN TRY
    -- 1. Insert into Purchase Order (Header)
    INSERT INTO PurchaseOrder (SupplierID, EmployeeID, OrderDate, TotalAmount)
    VALUES (1, 3, GETDATE(), 900000.00);

    -- Capture the auto-generated ID for the child table
    DECLARE @NewPOID INT = SCOPE_IDENTITY();

    -- 2. Insert into Payment (Child Table)
    INSERT INTO Payment (PurchaseOrderID, PaymentDate, Status)
    VALUES (@NewPOID, GETDATE(), 'Pending');

    -- Success: Save changes
    COMMIT TRANSACTION;
    PRINT 'Nestl� Procurement Transaction Completed Successfully';
END TRY
BEGIN CATCH
    -- Failure: Undo everything
    ROLLBACK TRANSACTION;
    PRINT 'Transaction Failed: Order and Payment rolled back';
END CATCH;